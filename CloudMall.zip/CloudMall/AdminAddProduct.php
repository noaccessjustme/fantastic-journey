<?php
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Handle adding a new product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $shop_id = $_POST['shop_id'];
    $product_name = htmlspecialchars($_POST['product_name']);
    $description = htmlspecialchars($_POST['description']);
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $image_url = htmlspecialchars($_POST['image_url']);

    // Check if the shop_id exists in the shops table
    $stmt = $conn->prepare("SELECT shop_id FROM shops WHERE shop_id = ?");
    $stmt->bind_param('i', $shop_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // If shop exists, proceed to insert product
        // Insert product into the products table
        $stmt = $conn->prepare("INSERT INTO products (product_name, product_description, image_url, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param('sss', $product_name, $description, $image_url);
        $stmt->execute();
        $product_id = $stmt->insert_id; // Get the newly inserted product ID

        // Insert price and stock into shopproducts table
        $stmt = $conn->prepare("INSERT INTO shopproducts (product_id, shop_id, price, stock, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param('iidi', $product_id, $shop_id, $price, $stock);
        $stmt->execute();

        // Redirect back to the product manager page
        header("Location: AdminProductManager.php");
        exit();
    } else {
        // If shop_id doesn't exist, show an error
        echo "Shop not found! Please select a valid shop.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #2196F3;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Add New Product</h2>

    <form action="AdminAddProduct.php" method="POST">
        <label for="shop_id">Shop ID</label>
        <input type="number" id="shop_id" name="shop_id" placeholder="Enter shop ID" required>

        <label for="product_name">Product Name</label>
        <input type="text" id="product_name" name="product_name" placeholder="Enter product name" required>

        <label for="description">Product Description</label>
        <textarea id="description" name="description" rows="4" placeholder="Enter product description" required></textarea>

        <label for="image_url">Image URL</label>
        <input type="text" id="image_url" name="image_url" placeholder="Enter image URL" required>

        <label for="price">Price</label>
        <input type="number" step="0.01" id="price" name="price" placeholder="Enter product price" required>

        <label for="stock">Stock</label>
        <input type="number" id="stock" name="stock" placeholder="Enter product stock" required>

        <button type="submit" name="add_product">Add Product</button>
    </form>

    <a href="AdminProductManager.php" class="back-link">Back to Product Management</a>
</div>

</body>
</html>
