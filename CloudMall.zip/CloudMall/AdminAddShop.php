<?php
require_once 'admin_header.php';
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Handle adding a new shop
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_shop'])) {
    $shop_name = htmlspecialchars($_POST['shop_name']);
    $shop_description = htmlspecialchars($_POST['shop_description']);
    $shop_url = htmlspecialchars($_POST['shop_url']);
    $shop_category = htmlspecialchars($_POST['shop_category']);
    
    // Handle shop logo upload
    $shop_logo = '';
    if (isset($_FILES['shop_logo']) && $_FILES['shop_logo']['error'] === UPLOAD_ERR_OK) {
        $logo_temp = $_FILES['shop_logo']['tmp_name'];
        $logo_name = basename($_FILES['shop_logo']['name']);
        $logo_target = "uploads/shops/" . $logo_name;

        // Move uploaded file to the target directory
        if (move_uploaded_file($logo_temp, $logo_target)) {
            $shop_logo = $logo_target; // Save the path to the database
        } else {
            echo "Error uploading logo.";
            exit();
        }
    }

    // Insert new shop into the database
    $stmt = $conn->prepare("INSERT INTO shops (shop_name, shop_description, shop_url, shop_logo, category, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param('sssss', $shop_name, $shop_description, $shop_url, $shop_logo, $shop_category);
    $stmt->execute();

    // Redirect back to the shop manager page
    header("Location: AdminShopManager.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Shop</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], textarea, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px; /* Space between inputs */
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        textarea {
            resize: vertical;
        }

        input[type="file"] {
            margin-bottom: 15px;
        }

        button {
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #2196F3;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Add New Shop</h2>

    <form action="AdminAddShop.php" method="POST" enctype="multipart/form-data">
        <label for="shop_name">Shop Name</label>
        <input type="text" id="shop_name" name="shop_name" placeholder="Enter shop name" required>

        <label for="shop_description">Shop Description</label>
        <textarea id="shop_description" name="shop_description" rows="4" placeholder="Enter shop description" required></textarea>

        <label for="shop_url">Shop URL</label>
        <input type="text" id="shop_url" name="shop_url" placeholder="Enter shop URL (e.g., https://example.com)" required>

        <label for="shop_logo">Shop Logo</label>
        <input type="file" id="shop_logo" name="shop_logo" accept="image/*" required>

        <label for="shop_category">Shop Category</label>
        <select id="shop_category" name="shop_category" required>
            <option value="" disabled selected>Select a category</option>
            <option value="clothing">Clothing</option>
            <option value="groceries">Groceries</option>
            <option value="electronics">Electronics</option>
        </select>

        <button type="submit" name="add_shop">Add Shop</button>
    </form>

    <a href="AdminShopManager.php" class="back-link">Back to Shop Management</a>
</div>

</body>
</html>
