<?php
require_once 'admin_header.php';
require_once 'session.php';
require_once 'dbconn.php';

// Check if the user is logged in and is an admin
if (!isset($_SESSION["user_id"]) || $_SESSION["user_role"] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Initialize error variables
$firstnameErr = $lastnameErr = $emailErr = $passwordErr = "";
$firstname = $lastname = $email = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate first name
    if (empty($_POST["firstname"])) {
        $firstnameErr = "First name is required";
    } else {
        $firstname = htmlspecialchars($_POST["firstname"]);
    }

    // Validate last name
    if (empty($_POST["lastname"])) {
        $lastnameErr = "Last name is required";
    } else {
        $lastname = htmlspecialchars($_POST["lastname"]);
    }

    // Validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = htmlspecialchars($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        } else {
            // Check if email already exists in the database
            $emailCheckQuery = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
            $emailCheckQuery->bind_param("s", $email);
            $emailCheckQuery->execute();
            $emailCheckQuery->store_result();
            if ($emailCheckQuery->num_rows > 0) {
                $emailErr = "Email already exists!";
            }
            $emailCheckQuery->close();
        }
    }

    // Validate password
    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } elseif (strlen($_POST["password"]) < 6) {
        $passwordErr = "Password must be at least 6 characters long";
    } else {
        $password = $_POST["password"];
    }

    // If no errors, insert data into the database
    if (empty($firstnameErr) && empty($lastnameErr) && empty($emailErr) && empty($passwordErr)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $role = 'admin'; // Set role to admin

        $insertQuery = $conn->prepare("INSERT INTO users (firstname, lastname, email, hash_password, user_role, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $insertQuery->bind_param("sssss", $firstname, $lastname, $email, $hashedPassword, $role);

        if ($insertQuery->execute()) {
            echo "New admin added successfully.";
        } else {
            echo "Error: " . $insertQuery->error;
        }

        $insertQuery->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        input {
            padding: 10px;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #45a049;
        }
        .error {
            color: red;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add New Admin</h2>
    <form action="AdminAddUser.php" method="POST">
        <input type="text" name="firstname" placeholder="First Name" value="<?php echo htmlspecialchars($firstname); ?>" required>
        <span class="error"><?php echo $firstnameErr; ?></span>
        
        <input type="text" name="lastname" placeholder="Last Name" value="<?php echo htmlspecialchars($lastname); ?>" required>
        <span class="error"><?php echo $lastnameErr; ?></span>

        <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($email); ?>" required>
        <span class="error"><?php echo $emailErr; ?></span>

        <input type="password" name="password" placeholder="Password" required>
        <span class="error"><?php echo $passwordErr; ?></span>

        <button type="submit">Add Admin</button>
    </form>
</div>

</body>
</html>
