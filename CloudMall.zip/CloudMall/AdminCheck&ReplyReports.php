<?php
require_once 'admin_header.php';
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Handle reply submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reply'])) {
    $message_id = intval($_POST['message_id']);
    $admin_reply = htmlspecialchars($_POST['admin_reply']);

    // Insert reply into report_replies table
    $stmt = $conn->prepare("INSERT INTO report_replies (message_id, admin_reply) VALUES (?, ?)");
    $stmt->bind_param('is', $message_id, $admin_reply);
    $stmt->execute();

    // Optionally, redirect to the same page to see the new replies
    header("Location: AdminCheck&ReplyReports.php");
    exit();
}

// Fetch all reports
$reports = $conn->query("SELECT * FROM reports ORDER BY submitted_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Check & Reply Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table thead {
            background-color: #4CAF50;
            color: white;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            padding: 10px 15px;
            color: white;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .reply-form {
            margin-top: 15px;
        }

        textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Check & Reply Reports</h2>

    <table>
        <thead>
            <tr>
                <th>Message ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Message</th>
                <th>Submitted At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($reports)): ?>
                <?php foreach ($reports as $report): ?>
                    <tr>
                        <td><?= $report['message_id']; ?></td>
                        <td><?= $report['fullname']; ?></td>
                        <td><?= $report['email']; ?></td>
                        <td><?= $report['contact']; ?></td>
                        <td><?= $report['messages']; ?></td>
                        <td><?= $report['submitted_at']; ?></td>
                        <td>
                            <form action="AdminCheck&ReplyReports.php" method="POST" class="reply-form">
                                <input type="hidden" name="message_id" value="<?= $report['message_id']; ?>">
                                <textarea name="admin_reply" placeholder="Type your reply here..." required></textarea>
                                <button type="submit" name="reply" class="btn">Reply</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7">No reports found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
