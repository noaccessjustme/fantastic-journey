<?php
// Dashboard.php
require_once 'admin_header.php';  // Header for the admin panel
require_once 'dbconn.php';

// Fetch stats from the database
$total_orders = $conn->query("SELECT COUNT(order_id) AS total FROM orders")->fetch_assoc()['total'];
$total_sales = $conn->query("SELECT SUM(total) AS total FROM payments WHERE payment_status = 'completed'")->fetch_assoc()['total'];
$total_users = $conn->query("SELECT COUNT(user_id) AS total FROM users")->fetch_assoc()['total'];
$total_products = $conn->query("SELECT COUNT(product_id) AS total FROM products")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        /* General container styling */
        .admin-dashboard {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        /* Stats container */
        .dashboard-stats {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        /* Individual stat box styling */
        .stat-item {
            flex: 1 1 calc(25% - 20px);
            background-color: #4CAF50;
            color: white;
            border-radius: 8px;
            padding: 20px;
            margin: 10px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-item:hover {
            transform: scale(1.05);
        }

        .stat-item h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        .stat-item p {
            font-size: 2rem;
            font-weight: bold;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .stat-item {
                flex: 1 1 100%;
            }
        }
    </style>
</head>
<body>

<div class="admin-dashboard">
    <h2>Admin Dashboard</h2>
    <div class="dashboard-stats">
        <div class="stat-item">
            <h3>Total Orders</h3>
            <p><?= $total_orders; ?></p>
        </div>
        <div class="stat-item">
            <h3>Total Sales</h3>
            <p>R<?= number_format($total_sales, 2); ?></p>
        </div>
        <div class="stat-item">
            <h3>Total Users</h3>
            <p><?= $total_users; ?></p>
        </div>
        <div class="stat-item">
            <h3>Total Products</h3>
            <p><?= $total_products; ?></p>
        </div>
    </div>
</div>

</body>
</html>
