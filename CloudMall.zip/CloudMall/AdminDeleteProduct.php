<?php
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Retrieve the product ID from the URL
$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;

if ($product_id === 0) {
    echo "Invalid product ID!";
    exit();
}

// First delete from the shopproducts table
$stmt = $conn->prepare("DELETE FROM shopproducts WHERE product_id = ?");
$stmt->bind_param('i', $product_id);
$stmt->execute();

// Then delete from the products table
$stmt = $conn->prepare("DELETE FROM products WHERE product_id = ?");
$stmt->bind_param('i', $product_id);
$stmt->execute();

// Redirect back to the product manager page after deletion
header("Location: AdminProductManager.php");
exit();
?>
