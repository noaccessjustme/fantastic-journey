<?php
require_once 'dbconn.php';

// Check if user_id is set
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Delete user from database
    $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();

    header("Location: AdminUserManager.php"); // Redirect to user management page
    exit();
}
?>
