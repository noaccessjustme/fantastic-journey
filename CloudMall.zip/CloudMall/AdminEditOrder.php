<?php
require_once 'admin_header.php';
require_once 'session.php'; // Include session management
require_once 'dbconn.php'; // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php"); // Redirect to login if not logged in
    exit();
}

// Get the order_id from the URL
if (!isset($_GET['order_id'])) {
    echo "No order selected!";
    exit();
}

$orderID = intval($_GET['order_id']);

// Fetch order details from the database
$stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
$stmt->bind_param("i", $orderID);
$stmt->execute();
$orderResult = $stmt->get_result();
$order = $orderResult->fetch_assoc();

// Check if the order exists
if (!$order) {
    echo "Order not found!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Order - <?= $order['order_id']; ?></title>
    <style>
        .admin-container {
            margin: 20px auto;
            padding: 20px;
            max-width: 800px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            color: #333;
            font-size: 2rem;
            margin-bottom: 20px;
        }
        .order-details {
            list-style: none;
            padding: 0;
        }
        .order-details li {
            margin-bottom: 10px;
        }
        .order-details span {
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>View Order #<?= $order['order_id']; ?></h2>
    <ul class="order-details">
        <li><span>Shop ID:</span> <?= $order['shop_id']; ?></li>
        <li><span>Total Amount:</span> R<?= number_format($order['total_amount'], 2); ?></li>
        <li><span>Payment Method:</span> <?= htmlspecialchars($order['payment_method']); ?></li>
        <li><span>Delivery Option:</span> <?= htmlspecialchars($order['delivery_option']); ?></li>
        <li><span>Residence Address:</span> <?= htmlspecialchars($order['residence_address']); ?></li>
        <li><span>Contact:</span> <?= htmlspecialchars($order['contact']); ?></li>
        <li><span>Order Status:</span> <?= $order['order_status']; ?></li>
        <li><span>Order Date:</span> <?= $order['created_at']; ?></li>
    </ul>
    <a href="UserOrderManager.php">Back to Orders</a>
</div>

</body>
</html>
