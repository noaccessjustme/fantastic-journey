<?php
require_once 'admin_header.php';
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Retrieve product ID from URL
$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;

if ($product_id === 0) {
    echo "Invalid product ID!";
    exit();
}

// Fetch product details from the database
$stmt = $conn->prepare("
    SELECT p.product_id, p.product_name, p.product_description, p.image_url, sp.price, sp.stock, sp.shop_id
    FROM products p
    JOIN shopproducts sp ON p.product_id = sp.product_id
    WHERE p.product_id = ?
");
$stmt->bind_param('i', $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    echo "Product not found!";
    exit();
}

// Handle form submission for updating the product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_product'])) {
    $shop_id = $_POST['shop_id'];
    $product_name = htmlspecialchars($_POST['product_name']);
    $description = htmlspecialchars($_POST['description']);
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $image_url = htmlspecialchars($_POST['image_url']);

    // Update product details
    $stmt = $conn->prepare("UPDATE products SET product_name = ?, product_description = ?, image_url = ?, updated_at = NOW() WHERE product_id = ?");
    $stmt->bind_param('sssi', $product_name, $description, $image_url, $product_id);
    $stmt->execute();

    // Update price and stock in shopproducts
    $stmt = $conn->prepare("UPDATE shopproducts SET price = ?, stock = ?, shop_id = ?, updated_at = NOW() WHERE product_id = ?");
    $stmt->bind_param('diii', $price, $stock, $shop_id, $product_id);
    $stmt->execute();

    // Redirect back to the product manager page
    header("Location: AdminProductManager.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #2196F3;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Edit Product</h2>

    <form action="AdminEditProduct.php?product_id=<?= $product_id ?>" method="POST">
        <label for="shop_id">Shop ID</label>
        <input type="number" id="shop_id" name="shop_id" value="<?= $product['shop_id'] ?>" required>

        <label for="product_name">Product Name</label>
        <input type="text" id="product_name" name="product_name" value="<?= $product['product_name'] ?>" required>

        <label for="description">Product Description</label>
        <textarea id="description" name="description" rows="4" required><?= $product['product_description'] ?></textarea>

        <label for="image_url">Image URL</label>
        <input type="text" id="image_url" name="image_url" value="<?= $product['image_url'] ?>" required>

        <label for="price">Price</label>
        <input type="number" step="0.01" id="price" name="price" value="<?= $product['price'] ?>" required>

        <label for="stock">Stock</label>
        <input type="number" id="stock" name="stock" value="<?= $product['stock'] ?>" required>

        <button type="submit" name="update_product">Update Product</button>
    </form>

    <a href="AdminProductManager.php" class="back-link">Back to Product Management</a>
</div>

</body>
</html>
