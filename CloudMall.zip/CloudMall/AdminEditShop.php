<?php
require_once 'admin_header.php';
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Check if shop_id is provided
if (!isset($_GET['shop_id']) || !is_numeric($_GET['shop_id'])) {
    echo "Shop not found!";
    exit();
}

$shop_id = intval($_GET['shop_id']);

// Fetch the current shop details
$stmt = $conn->prepare("SELECT * FROM shops WHERE shop_id = ?");
$stmt->bind_param('i', $shop_id);
$stmt->execute();
$result = $stmt->get_result();
$shop = $result->fetch_assoc();

if (!$shop) {
    echo "Shop not found!";
    exit();
}

// Handle the form submission for updating the shop
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_shop'])) {
    $shop_name = htmlspecialchars($_POST['shop_name']);
    $shop_description = htmlspecialchars($_POST['shop_description']);
    $shop_url = htmlspecialchars($_POST['shop_url']);

    // Handle shop logo upload
    $shop_logo = $shop['shop_logo']; // Keep existing logo if not uploaded
    if (isset($_FILES['shop_logo']) && $_FILES['shop_logo']['error'] === UPLOAD_ERR_OK) {
        $logo_temp = $_FILES['shop_logo']['tmp_name'];
        $logo_name = basename($_FILES['shop_logo']['name']);
        $logo_target = "uploads/shops/" . $logo_name;

        // Move the uploaded logo
        if (move_uploaded_file($logo_temp, $logo_target)) {
            $shop_logo = $logo_target; // Update the logo path
        } else {
            echo "Error uploading the logo!";
            exit();
        }
    }

    // Update the shop in the database
    $update_stmt = $conn->prepare("UPDATE shops SET shop_name = ?, shop_description = ?, shop_url = ?, shop_logo = ?, updated_at = NOW() WHERE shop_id = ?");
    $update_stmt->bind_param('ssssi', $shop_name, $shop_description, $shop_url, $shop_logo, $shop_id);
    $update_stmt->execute();
    
    // Redirect to the AdminShopManager page after updating
    header("Location: AdminShopManager.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Shop - <?php echo htmlspecialchars($shop['shop_name']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="url"], textarea, input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        textarea {
            resize: vertical;
        }

        button {
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #2196F3;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Edit Shop - <?php echo htmlspecialchars($shop['shop_name']); ?></h2>

    <form action="AdminEditShop.php?shop_id=<?php echo $shop_id; ?>" method="POST" enctype="multipart/form-data">
        <label for="shop_name">Shop Name</label>
        <input type="text" id="shop_name" name="shop_name" value="<?php echo htmlspecialchars($shop['shop_name']); ?>" required>

        <label for="shop_description">Shop Description</label>
        <textarea id="shop_description" name="shop_description" rows="4" required><?php echo htmlspecialchars($shop['shop_description']); ?></textarea>

        <label for="shop_url">Shop URL</label>
        <input type="url" id="shop_url" name="shop_url" value="<?php echo htmlspecialchars($shop['shop_url']); ?>" required>

        <label for="shop_logo">Shop Logo</label>
        <input type="file" id="shop_logo" name="shop_logo" accept="image/*">

        <p>Current Logo: <img src="<?php echo htmlspecialchars($shop['shop_logo']); ?>" alt="Shop Logo" width="100"></p>

        <button type="submit" name="update_shop">Update Shop</button>
    </form>

    <a href="AdminShopManager.php" class="back-link">Back to Shop Management</a>
</div>

</body>
</html>
