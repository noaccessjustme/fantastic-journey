<?php
require_once 'admin_header.php';
require_once 'dbconn.php';
require_once 'admin_header.php';

// Initialize variables
$user_id = $firstname = $lastname = $email = $user_role = '';

// Fetch user data if user_id is set
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if ($user) {
        $firstname = $user['firstname'];
        $lastname = $user['lastname'];
        $email = $user['email'];
        $user_role = $user['user_role'];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $user_role = $_POST['user_role'];

    // Update user in database
    $stmt = $conn->prepare("UPDATE users SET firstname = ?, lastname = ?, email = ?, user_role = ? WHERE user_id = ?");
    $stmt->bind_param('ssssi', $firstname, $lastname, $email, $user_role, $user_id);
    $stmt->execute();

    header("Location: AdminUserManager.php"); // Redirect to user management page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        /* General page styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            font-size: 2rem;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-size: 1rem;
            color: #555;
        }

        input[type="text"],
        input[type="email"],
        select {
            width: 100%;
            padding: 10px;
            font-size: 1rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            padding: 10px;
            font-size: 1rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #2196F3;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit User</h2>
    <form method="POST" action="">
        <label for="firstname">First Name:</label>
        <input type="text" name="firstname" value="<?= htmlspecialchars($firstname); ?>" required>
        
        <label for="lastname">Last Name:</label>
        <input type="text" name="lastname" value="<?= htmlspecialchars($lastname); ?>" required>
        
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($email); ?>" required>
        
        <label for="user_role">Role:</label>
        <select name="user_role" required>
            <option value="admin" <?= $user_role == 'admin' ? 'selected' : ''; ?>>Admin</option>
            <option value="user" <?= $user_role == 'user' ? 'selected' : ''; ?>>Customer</option>
        </select>
        
        <button type="submit">Update User</button>
    </form>
    <div class="back-link">
        <a href="AdminUserManager.php">Back to User Management</a>
    </div>
</div>

</body>
</html>
