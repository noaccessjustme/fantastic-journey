<?php
require_once 'admin_header.php';
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Fetch all pending orders
$query = "SELECT * FROM orders WHERE order_status = 'Pending'"; // Assuming there is an 'order_status' column in the orders table
$result = $conn->query($query);

if ($result->num_rows === 0) {
    echo "No pending orders.";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Order Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .admin-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .confirm-button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .confirm-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Pending Orders</h2>

    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>User ID</th>
                <th>Shop ID</th>
                <th>Total Amount</th>
                <th>Payment Method</th>
                <th>Delivery Option</th>
                <th>Address</th>
                <th>Contact</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $order['order_id']; ?></td>
                    <td><?= $order['user_id']; ?></td>
                    <td><?= $order['shop_id']; ?></td>
                    <td>R<?= number_format($order['total_amount'], 2); ?></td>
                    <td><?= htmlspecialchars($order['payment_method']); ?></td>
                    <td><?= htmlspecialchars($order['delivery_option']); ?></td>
                    <td><?= htmlspecialchars($order['address']); ?></td>
                    <td><?= htmlspecialchars($order['contact']); ?></td>
                    <td>
                        <form action="AdminOrderConfirm.php" method="POST" style="display:inline;">
                            <input type="hidden" name="order_id" value="<?= $order['order_id']; ?>">
                            <button type="submit" class="confirm-button">Confirm</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php
// Handle confirmation of the order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
    
    // Update the order status to confirmed
    $confirm_stmt = $conn->prepare("UPDATE orders SET order_status = 'Confirmed' WHERE order_id = ?");
    $confirm_stmt->bind_param('i', $order_id);
    $confirm_stmt->execute();
    
    // Redirect back to the order confirmation page
    header("Location: AdminOrderConfirm.php");
    exit();
}
?>
