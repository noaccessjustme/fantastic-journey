<?php
require_once 'admin_header.php';
require_once 'session.php'; // Include session management
require_once 'dbconn.php'; // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php"); // Redirect to login if not logged in
    exit();
}

// Fetch all orders from the database (removing user_id condition)
$stmt = $conn->prepare("SELECT * FROM orders");
$stmt->execute();
$ordersResult = $stmt->get_result();
$orders = $ordersResult->fetch_all(MYSQLI_ASSOC);

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id'], $_POST['order_status'])) {
    $orderID = intval($_POST['order_id']);
    $orderStatus = $_POST['order_status'];

    // Update the order status in the database
    $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");
    $stmt->bind_param("si", $orderStatus, $orderID);
    $stmt->execute();

    header("Location: AdminOrderManager.php"); // Refresh the page after updating
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Management</title>
    <style>
        /* Admin container and table styles */
        .admin-container {
            margin: 20px auto;
            padding: 20px;
            max-width: 1200px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            color: #333;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        /* Table Styles */
        .table-container {
            overflow-x: auto;
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .admin-table thead {
            background-color: #f2f2f2;
        }

        .admin-table th,
        .admin-table td {
            text-align: left;
            padding: 12px 15px;
            border: 1px solid #ddd;
            color: #333;
        }

        .admin-table th {
            background-color: #4CAF50;
            color: #fff;
        }

        .admin-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .admin-table tr:hover {
            background-color: #f1f1f1;
        }

        /* Button Styles */
        .button-link {
            color: #fff;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 5px;
            background-color: #4CAF50;
            transition: background-color 0.3s ease;
            display: inline-block;
        }

        .button-link:hover {
            background-color: #45a049;
        }

        .button-link.cancel {
            background-color: #f44336;
        }

        .button-link.cancel:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Order Management</h2>
    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>User ID</th>
                    <th>Shop ID</th>
                    <th>Total Amount</th>
                    <th>Payment Method</th>
                    <th>Delivery Option</th>
                    <th>Residence Address</th>
                    <th>Contact</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($orders)): ?>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= $order['order_id']; ?></td>
                            <td><?= $order['user_id']; ?></td>
                            <td><?= $order['shop_id']; ?></td>
                            <td>R<?= number_format($order['total_amount'], 2); ?></td>
                            <td><?= htmlspecialchars($order['payment_method']); ?></td>
                            <td><?= htmlspecialchars($order['delivery_option']); ?></td>
                            <td><?= htmlspecialchars($order['residence_address']); ?></td>
                            <td><?= htmlspecialchars($order['contact']); ?></td>
                            <td><?= $order['order_status']; ?></td>
                            <td><?= $order['created_at']; ?></td>
                            <td>
                                <a href="AdminEditOrder.php?order_id=<?= $order['order_id']; ?>" class="button-link">View Order</a>
                                <a href="AdminUpdateOrderStatus.php?order_id=<?= $order['order_id']; ?>" class="button-link cancel">Update Status</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11">No orders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
