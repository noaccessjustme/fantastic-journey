<?php
require_once 'admin_header.php';
require_once 'dbconn.php';
require_once 'admin_header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle form submission for adding or editing products
    $product_name = $_POST['product_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $shop_id = $_POST['shop_id'];
    $image_url = $_POST['image_url'];

    if (isset($_POST['add_product'])) {
        // Insert product into the products table
        $stmt = $conn->prepare("INSERT INTO products (product_name, product_description, image_url, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param('sss', $product_name, $description, $image_url);
        $stmt->execute();
        $product_id = $stmt->insert_id; // Get the newly inserted product ID

        // Insert price and stock into shopproducts table
        $stmt = $conn->prepare("INSERT INTO shopproducts (product_id, shop_id, price, stock, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param('iidi', $product_id, $shop_id, $price, $stock);
        $stmt->execute();
    } elseif (isset($_POST['edit_product'])) {
        // Update product details in products table
        $product_id = $_POST['product_id'];
        $stmt = $conn->prepare("UPDATE products SET product_name = ?, product_description = ?, image_url = ?, updated_at = NOW() WHERE product_id = ?");
        $stmt->bind_param('sssi', $product_name, $description, $image_url, $product_id);
        $stmt->execute();

        // Update price and stock in shopproducts table
        $stmt = $conn->prepare("UPDATE shopproducts SET price = ?, stock = ?, updated_at = NOW() WHERE product_id = ? AND shop_id = ?");
        $stmt->bind_param('diii', $price, $stock, $product_id, $shop_id);
        $stmt->execute();
    }
}

// Fetch all products with their price, stock, and shop information for listing
$products = $conn->query("
    SELECT p.product_id, p.product_name, p.product_description, p.image_url, sp.price, sp.stock, sp.shop_id
    FROM products p
    JOIN shopproducts sp ON p.product_id = sp.product_id
")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Product Management</title>
    <style>
        /* Container styling */
        .admin-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        /* Table styling */
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .admin-table th, .admin-table td {
            padding: 12px 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        .admin-table thead {
            background-color: #4CAF50;
            color: white;
        }

        .admin-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .admin-table tbody tr:hover {
            background-color: #f1f1f1;
        }

        img {
            max-width: 100px;
            height: auto;
        }

        /* Button styling */
        .btn {
            padding: 10px 15px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 15px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .btn-primary {
            background-color: #4CAF50;
        }

        .btn-primary:hover {
            background-color: #45a049;
        }

        /* Action Links */
        .action-link {
            color: #2196F3;
            text-decoration: none;
            margin-right: 10px;
        }

        .action-link:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>

<div class="admin-container">
    <h2>Product Management</h2>
    <a href="AdminAddProduct.php" class="btn btn-primary">Add New Product</a>

    <table class="admin-table">
        <thead>
            <tr>
                <th>Shop ID</th>
                <th>Product Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?= $product['shop_id']; ?></td>
                        <td><?= $product['product_name']; ?></td>
                        <td><?= $product['product_description']; ?></td>
                        <td><img src="<?= $product['image_url']; ?>" alt="Product Image"></td>
                        <td>$<?= number_format($product['price'], 2); ?></td>
                        <td><?= $product['stock']; ?></td>
                        <td>
                            <a href="AdminEditProduct.php?product_id=<?= $product['product_id']; ?>" class="action-link">Edit</a> |
                            <a href="AdminDeleteProduct.php?product_id=<?= $product['product_id']; ?>" class="action-link" onclick="return confirm('Are you sure?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7">No products found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
