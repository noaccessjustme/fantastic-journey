<?php
require_once 'admin_header.php';
require_once 'session.php'; // Include session management
require_once 'dbconn.php';  // Include database connection

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: Login.php"); // Redirect to login if not logged in
    exit();
}

// Fetch return requests
$stmt = $conn->prepare("
    SELECT r.return_id, r.order_id, r.product_id, r.reason, r.status, u.fullname, p.product_name
    FROM returns r
    JOIN users u ON r.user_id = u.user_id
    JOIN products p ON r.product_id = p.product_id
    WHERE r.status = 'Pending'
");
$stmt->execute();
$result = $stmt->get_result();
$returnRequests = $result->fetch_all(MYSQLI_ASSOC);

// Handle admin's response to a return request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $return_id = $_POST['return_id'];
    $newStatus = $_POST['status'];

    // Update the return status in the database
    $stmt = $conn->prepare("UPDATE returns SET status = ? WHERE return_id = ?");
    $stmt->bind_param("si", $newStatus, $return_id);
    if ($stmt->execute()) {
        echo "Return request updated successfully!";
        header("Refresh: 0"); // Refresh the page to show updated status
        exit();
    } else {
        echo "Failed to update return request.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Returns</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        select, button {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Manage Return Requests</h2>

    <table>
        <thead>
            <tr>
                <th>Return ID</th>
                <th>User</th>
                <th>Product</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($returnRequests as $request): ?>
                <tr>
                    <td><?= $request['return_id']; ?></td>
                    <td><?= $request['fullname']; ?></td>
                    <td><?= $request['product_name']; ?></td>
                    <td><?= $request['reason']; ?></td>
                    <td><?= $request['status']; ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="return_id" value="<?= $request['return_id']; ?>">
                            <select name="status" required>
                                <option value="Approved">Approve</option>
                                <option value="Rejected">Reject</option>
                            </select>
                            <button type="submit">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
