<?php
require_once 'admin_header.php';
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: Login.php"); // Redirect to login if not authorized
    exit();
}

// Fetch all shops from the database
$shops = $conn->query("SELECT * FROM shops")->fetch_all(MYSQLI_ASSOC);

// Handle deleting a shop
if (isset($_GET['delete_shop_id'])) {
    $delete_shop_id = intval($_GET['delete_shop_id']);
    $stmt = $conn->prepare("DELETE FROM shops WHERE shop_id = ?");
    $stmt->bind_param('i', $delete_shop_id);
    $stmt->execute();
    header("Location: AdminShopManager.php"); // Refresh the page after deleting a shop
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Shop Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 30px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table thead {
            background-color: #4CAF50;
            color: white;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tbody tr:hover {
            background-color: #f1f1f1;
        }

        img {
            max-width: 100px;
            height: auto;
        }

        .btn {
            padding: 10px 15px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 15px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .btn-primary {
            background-color: #4CAF50;
        }

        .btn-primary:hover {
            background-color: #45a049;
        }

        .btn-danger {
            background-color: #f44336;
        }

        .btn-danger:hover {
            background-color: #d32f2f;
        }

        .add-shop-btn {
            display: block;
            margin-bottom: 20px;
            text-align: center;
        }

        .add-shop-btn a {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .add-shop-btn a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Shop Management</h2>

    <!-- Add Shop Button -->
    <div class="add-shop-btn">
        <a href="AdminAddShop.php">Add New Shop</a>
    </div>

    <!-- Shop List -->
    <table>
        <thead>
            <tr>
                <th>Shop ID</th>
                <th>Shop Name</th>
                <th>Description</th>
                <th>URL</th>
                <th>Logo</th>
                <th>Category</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($shops as $shop): ?>
                <tr>
                    <td><?php echo $shop['shop_id']; ?></td>
                    <td><?php echo $shop['shop_name']; ?></td>
                    <td><?php echo $shop['shop_description']; ?></td>
                    <td><a href="<?php echo $shop['shop_url']; ?>" target="_blank"><?php echo $shop['shop_url']; ?></a></td>
                    <td>
                        <?php if (!empty($shop['shop_logo'])): ?>
                            <img src="<?php echo $shop['shop_logo']; ?>" alt="Shop Logo">
                        <?php else: ?>
                            No Logo
                        <?php endif; ?>
                    </td>
                    <td><?php echo $shop['category']; ?></td>
                    <td><?php echo $shop['created_at']; ?></td>
                    <td>
                        <a href="AdminEditShop.php?shop_id=<?php echo $shop['shop_id']; ?>" class="btn btn-primary">Edit</a>
                        <a href="AdminShopManager.php?delete_shop_id=<?php echo $shop['shop_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
