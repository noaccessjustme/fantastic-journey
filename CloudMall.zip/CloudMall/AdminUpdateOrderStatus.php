<?php
require_once 'dbconn.php';
require_once 'admin_header.php';

// Initialize variables
$order_id = $status = '';

// Fetch order data if order_id is set
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $stmt->bind_param('i', $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $order = $result->fetch_assoc();

    if ($order) {
        $status = $order['order_status'];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $status = $_POST['order_status'];

    // Update order status in database
    $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");
    $stmt->bind_param('si', $status, $order_id);
    $stmt->execute();

    header("Location: AdminOrderManager.php"); // Redirect to order management page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order Status</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
            color: #555;
        }

        select, input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        button {
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        a {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: white;
            background-color: #007BFF;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Update Order Status</h2>
    <form method="POST" action="">
        <label for="status">Current Status:</label>
        <select name="status" required>
            <option value="Pending" <?= $status == 'Pending' ? 'selected' : ''; ?>>Pending</option>
            <option value="Completed" <?= $status == 'Completed' ? 'selected' : ''; ?>>Completed</option>
            <option value="Canceled" <?= $status == 'Canceled' ? 'selected' : ''; ?>>Canceled</option>
        </select>
        
        <button type="submit">Update Status</button>
    </form>
    <a href="AdminOrderManager.php">Back to Order Management</a>
</div>

</body>
</html>
