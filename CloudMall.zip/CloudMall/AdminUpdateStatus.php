<?php
require_once 'admin_header.php';
require_once 'session.php'; // Include session management
require_once 'dbconn.php'; // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php"); // Redirect to login if not logged in
    exit();
}

// Get the order_id from the URL
if (!isset($_GET['order_id'])) {
    echo "No order selected!";
    exit();
}

$orderID = intval($_GET['order_id']);

// Fetch the current order status from the database
$stmt = $conn->prepare("SELECT order_status FROM orders WHERE order_id = ?");
$stmt->bind_param("i", $orderID);
$stmt->execute();
$orderResult = $stmt->get_result();
$order = $orderResult->fetch_assoc();

// Check if the order exists
if (!$order) {
    echo "Order not found!";
    exit();
}

// Handle form submission to update the order status
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newStatus = $_POST['order_status'];

    // Update the order status in the database
    $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");
    $stmt->bind_param("si", $newStatus, $orderID);
    if ($stmt->execute()) {
        // Redirect back to the previous page
        header("Location: UserOrderManager.php"); 
        exit();
    } else {
        echo "Failed to update order status!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order Status - <?= $orderID; ?></title>
    <style>
        .admin-container {
            margin: 20px auto;
            padding: 20px;
            max-width: 800px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            color: #333;
            font-size: 2rem;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #333;
            padding: 10px 20px;
            background-color: #f2f2f2;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        a:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <h2>Update Status for Order #<?= $orderID; ?></h2>

    <form action="" method="POST">
        <div class="form-group">
            <label for="order_status">Order Status</label>
            <select name="order_status" id="order_status">
                <option value="Pending" <?= ($order['order_status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                <option value="Processing" <?= ($order['order_status'] == 'Processing') ? 'selected' : ''; ?>>Processing</option>
                <option value="Shipped" <?= ($order['order_status'] == 'Shipped') ? 'selected' : ''; ?>>Shipped</option>
                <option value="Delivered" <?= ($order['order_status'] == 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                <option value="Canceled" <?= ($order['order_status'] == 'Canceled') ? 'selected' : ''; ?>>Canceled</option>
            </select>
        </div>

        <button type="submit">Update Status</button>
    </form>

    <a href="UserOrderManager.php">Back to Orders</a>
</div>

</body>
</html>
