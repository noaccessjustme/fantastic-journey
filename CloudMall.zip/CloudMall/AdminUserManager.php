<?php
require_once 'dbconn.php';
require_once 'admin_header.php';

// Initialize search variables
$searchTerm = "";

// Fetch users from the database
if (isset($_POST['search'])) {
    $searchTerm = test_input($_POST['search_term']);
    $stmt = $conn->prepare("SELECT * FROM users WHERE email LIKE ? OR user_id LIKE ?");
    $likeTerm = "%$searchTerm%";
    $stmt->bind_param("ss", $likeTerm, $likeTerm);
} else {
    $stmt = $conn->prepare("SELECT * FROM users");
}

$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Function to sanitize input data
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <style>
        /* General styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .admin-users {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table thead {
            background-color: #4CAF50;
            color: white;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        table th {
            font-size: 1.1rem;
        }

        table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Highlighted row */
        .highlight {
            background-color: yellow; /* Change this to your preferred highlight color */
        }

        a {
            color: #2196F3;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            color: white;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #2196F3;
        }

        .btn-danger {
            background-color: #f44336;
        }

        .btn:hover {
            opacity: 0.9;
        }

        /* Search bar styling */
        .search-container {
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        input[type="text"] {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 70%; /* Set width to 70% of the container */
        }

        /* Responsive table design */
        @media (max-width: 768px) {
            table, tbody, th, td, tr {
                display: block;
                width: 100%;
            }

            table thead {
                display: none;
            }

            table tr {
                margin-bottom: 20px;
            }

            table td {
                display: flex;
                justify-content: space-between;
                padding: 10px;
                border-bottom: 1px solid #ddd;
            }

            table td:before {
                content: attr(data-label);
                flex-basis: 50%;
                text-align: left;
                font-weight: bold;
            }
        }
    </style>
</head>
<body>

<div class="admin-users">
    <h2>User Management</h2>

    <div class="search-container">
        <form action="AdminUserManager.php" method="POST" style="flex-grow: 1; margin-right: 10px;">
            <input type="text" name="search_term" placeholder="Search by email or user ID" value="<?php echo htmlspecialchars($searchTerm); ?>">
            <button class="btn btn-primary" type="submit" name="search">Search</button>
        </form>
        <form action="AdminAddUser.php" method="GET">
            <button class="btn btn-primary" type="submit">Add Admin</button>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>User ID</th>
                <th>Email</th>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr class="<?php echo (strpos($user['email'], $searchTerm) !== false || strpos((string)$user['user_id'], $searchTerm) !== false) ? 'highlight' : ''; ?>">
                    <td data-label="User ID"><?= $user['user_id']; ?></td>
                    <td data-label="Email"><?= $user['email']; ?></td>
                    <td data-label="Firstname"><?= $user['firstname']; ?></td>
                    <td data-label="Lastname"><?= $user['lastname']; ?></td>
                    <td data-label="Role"><?= $user['user_role']; ?></td>
                    <td data-label="Actions">
                        <a href="AdminEditUser.php?user_id=<?= $user['user_id']; ?>" class="btn btn-primary">Edit</a> 
                        <a href="AdminDeleteUser.php?user_id=<?= $user['user_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
