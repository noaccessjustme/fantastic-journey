<?php
require_once 'dbconn.php';
require_once 'admin_header.php';

// Fetch order details if order_id is set
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $stmt->bind_param('i', $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $order = $result->fetch_assoc();
} else {
    // Redirect if no order_id is provided
    header("Location: AdminOrderManager.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Order</title>
    <style>
        /* General page styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            font-size: 2rem;
            color: #333;
        }

        p {
            font-size: 1rem;
            color: #555;
            line-height: 1.6;
            margin: 10px 0;
        }

        p strong {
            color: #333;
        }

        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #45a049;
        }

        .back-link {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Order Details</h2>
    <p><strong>Order ID:</strong> <?= htmlspecialchars($order['order_id']); ?></p>
    <p><strong>User ID:</strong> <?= htmlspecialchars($order['user_id']); ?></p>
    <p><strong>Total Amount:</strong> $<?= number_format($order['total_amount'], 2); ?></p>
    <p><strong>Status:</strong> <?= htmlspecialchars($order['status']); ?></p>
    <p><strong>Created At:</strong> <?= htmlspecialchars($order['created_at']); ?></p>

    <div class="back-link">
        <a href="AdminOrderManager.php">Back to Order Management</a>
    </div>
</div>

</body>
</html>
