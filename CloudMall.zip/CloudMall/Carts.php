<?php 
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

$isLoggedIn = $_SESSION['user_id']; // Logged-in user's ID

// Check if shop_id is provided, and validate it
if (!isset($_GET['shop_id']) || !is_numeric($_GET['shop_id'])) {
    echo "Shop not found! Please select a valid shop.";
    header("Refresh: 3; url=ShopsCards.php");
    exit();
}

$shop_id = intval($_GET['shop_id']); // Get the current shop ID

// Initialize the user's cart for this shop if it doesn't exist
if (!isset($_SESSION['carts'][$user_id][$shop_id])) {
    $_SESSION['carts'][$user_id][$shop_id] = [];
}

// Fetch the user's cart for this shop
$cartItems = $_SESSION['carts'][$isLoggedIn][$shop_id];

// Get product details from the database for each cart item
$productIds = array_keys($cartItems);
$products = [];

if (!empty($productIds)) {
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));
    $stmt = $conn->prepare("
        SELECT p.product_id, p.product_name, sp.price, p.image_url
        FROM products p
        JOIN shopproducts sp ON p.product_id = sp.product_id
        WHERE p.product_id IN ($placeholders) AND sp.shop_id = ?
    ");

    $types = str_repeat('i', count($productIds)) . 'i'; // Types string for bind_param
    $params = array_merge($productIds, [$shop_id]); // Parameters array

    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $products = $result->fetch_all(MYSQLI_ASSOC);
} else {
    echo "Your cart for this store is empty.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart for Store #<?php echo $shop_id; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin: 20px;
            color: #333;
        }
        /* Cart List Styling */
        .cart-items {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px;
        }
        .cart-item {
            border: 1px solid #ddd;
            padding: 20px;
            text-align: center;
            background-color: #fff;
        }
        .cart-item img {
            max-width: 100%;
            height: auto;
        }
        .cart-item h3 {
            margin: 10px 0;
        }
        .cart-item p {
            margin: 5px 0;
        }
        .cart-total {
            font-weight: bold;
            font-size: 1.5em;
            text-align: right;
            margin-right: 20px;
        }
        /* Checkout Button */
        .checkout-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            text-align: center;
            display: block;
            width: fit-content;
            margin: 20px auto;
            text-decoration: none;
            border-radius: 5px;
        }
        .checkout-btn:hover {
            background-color: #218838;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>

<h1>Your Cart for Store #<?php echo $shop_id; ?></h1>

<div class="cart-items">
    <?php if (!empty($products)): ?>
        <?php
        $total = 0;
        foreach ($products as $product):
            $quantity = $cartItems[$product['product_id']]['quantity'];
            $subtotal = $quantity * $product['price'];
            $total += $subtotal;
        ?>
            <div class="cart-item">
                <img src="<?php echo $product['image_url']; ?>" alt="<?php echo $product['product_name']; ?>">
                <h3><?php echo $product['product_name']; ?></h3>
                <p>Quantity: <?php echo $quantity; ?></p>
                <p>Price: R<?php echo number_format($product['price'], 2); ?></p>
                <p>Subtotal: R<?php echo number_format($subtotal, 2); ?></p>
            </div>
        <?php endforeach; ?>
        <div class="cart-total">
            Total: R<?php echo number_format($total, 2); ?>
        </div>
        <a href="Payment.php?shop_id=<?php echo $shop_id; ?>" class="checkout-btn">Proceed to Checkout</a>
    <?php else: ?>
        <p>Your cart is empty!</p>
    <?php endif; ?>
</div>

</body>
</html>
