<?php
// Database connection details
require_once 'dbconn.php';
require_once 'session.php';
// Initialize a message variable for feedback
$feedback_message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize inputs
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $contact = mysqli_real_escape_string($conn, trim($_POST['contact']));
    $message = mysqli_real_escape_string($conn, trim($_POST['message']));

    // Validate form fields
    if (!empty($name) && !empty($email) && !empty($contact) && !empty($message)) {
    
        // Validate email format
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Prepare the SQL query to insert data into the contact_messages table
            $sql = "INSERT INTO reports (fullname, email, contact, messages) VALUES (?, ?, ?, ?)";
    
            // Prepare the statement
            $stmt = $conn->prepare($sql);
    
            if ($stmt) {
                // Bind the parameters
                $stmt->bind_param("ssss", $name, $email, $contact, $message);
    
                // Execute the query and check for success
                if ($stmt->execute()) {
                    $feedback_message = "Your message has been successfully sent!";
                } else {
                    $feedback_message = "Error: " . $conn->error;
                }
    
                // Close the statement
                $stmt->close();
            } else {
                $feedback_message = "Error preparing statement: " . $conn->error;
            }
        } else {
            $feedback_message = "Please enter a valid email address.";
        }
    } else {
        $feedback_message = "Please fill in all the fields.";
    }
    
    // Close the database connection
    $conn->close();
}    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            border: none;
        }

        /* Body styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #fff;
            color: #333;
            padding: 20px;
        }

        /* Container */
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
        }

        /* Header styling */
        header {
            text-align: center;
            margin-bottom: 30px;
        }

        header h1 {
            font-size: 36px;
            color: #fbc02d;
        }

        /* Contact info styling */
        .contact-info {
            background-color: #333;
            padding: 20px;
            color: #fff;
            margin-bottom: 30px;
            border-radius: 10px;
        }

        .contact-info h2 {
            color: #fbc02d;
            margin-bottom: 10px;
        }

        .contact-info p {
            font-size: 18px;
        }

        .contact-info a {
            color: #fbc02d;
            text-decoration: none;
        }

        .contact-info a:hover {
            text-decoration: underline;
        }

        /* Contact form styling */
        .contact-form h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            font-size: 16px;
            color: #333;
            margin-bottom: 5px;
        }

        .input-group input, .input-group textarea {
            width: 100%;
            padding: 12px;
            border-radius: 5px;
            font-size: 16px;
        }

        input:focus, textarea:focus {
            outline: none;
            background-color: #f9f9f9;
        }

        button {
            padding: 12px 20px;
            background-color: #fbc02d;
            border: none;
            color: #333;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #333;
            color: #fff;
        }

        /* Feedback message */
        .feedback {
            margin-top: 20px;
            font-size: 18px;
            color: #28a745;
        }

        .error {
            color: #dc3545;
        }

        /* Location section */
        .location h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        .map {
            width: 100%;
            height: 300px;
            background-color: #f9f9f9;
            border-radius: 10px;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            position: absolute;
            top: 20px;
            left: 20px;
            
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }

    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>

<button class="back-button" onclick="window.history.back();">Back</button> <!-- Back button -->

    <div class="container">
        <header>
            <h1>Contact Us</h1>
        </header>

        <section class="contact-info">
            <h2>Our Contact Details</h2>
            <p><strong>Phone 1:</strong> +27 62 582 8950</p>
            <p><strong>Phone 2:</strong> +27 71 023 6594</p>
            <p><strong>Email:</strong> <a href="mailto:cloudmall@mysite.co.za">cloudmall@mysite.co.za</a></p>
            <p><strong>Address:</strong> 02 St Michaels, Southernwood, East London</p>
        </section>

        <section class="contact-form">
            <h2>Send Us a Message</h2>
            <form action="" method="POST" id="contact-form">
                <div class="input-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" placeholder="Your full name" required>
                </div>

                <div class="input-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Your email address" required>
                </div>

                <div class="input-group">
                    <label for="contact">Contact Number</label>
                    <input type="tel" id="contact" name="contact" placeholder="Your contact number" required>
                </div>

                <div class="input-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" placeholder="Your message here..." required></textarea>
                </div>

                <button type="submit">Submit</button>
            </form>

            <!-- Feedback message display -->
            <?php if (!empty($feedback_message)): ?>
                <div class="feedback <?php echo strpos($feedback_message, 'Error') !== false ? 'error' : ''; ?>">
                    <?php echo htmlspecialchars($feedback_message); ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="location">
            <h2>Find Us</h2>
            <div id="map" class="map"></div>
        </section>
    </div>

    <!-- Initialize Google Map -->
    <script>

        window.onload = function() {
            initMap();
        };

        function initMap() {
            const location = { lat: -32.9854, lng: 27.8726 };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 15,
                center: location
            });
            const marker = new google.maps.Marker({
                position: location,
                map: map
            });
        }
    </script>

    <!-- Load Google Maps API -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5u0WfRr2_-ayB_zPJCG5IHD0-pXlPJRk&callback=initMap" async defer></script>
</body>
</html>
