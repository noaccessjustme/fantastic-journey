<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frequently Asked Questions (FAQ)</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .faq-section {
            margin-bottom: 20px;
        }
        .faq-section h2 {
            background-color: #fbc02d;
            color: #333;
            padding: 10px;
            border-radius: 5px;
        }
        .faq-section p {
            padding: 10px;
            background-color: #f4f4f4;
            border-radius: 5px;
            margin: 0;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Frequently Asked Questions (FAQ)</h1>

    <div class="faq-section">
        <h2>1. How do I place an order?</h2>
        <p>To place an order, browse through our products, add them to your cart, and proceed to checkout. You'll need to provide your delivery details and payment information.</p>
    </div>

    <div class="faq-section">
        <h2>2. What payment methods are accepted?</h2>
        <p>We accept various payment methods, including credit/debit cards, online banking, and mobile payments.</p>
    </div>

    <div class="faq-section">
        <h2>3. Can I return a product?</h2>
        <p>Yes, you can return products by requesting a return on the product's order page. Please provide the order number, the product you wish to return, and a reason for the return.</p>
    </div>

    <div class="faq-section">
        <h2>4. How can I track my order?</h2>
        <p>You can track your order by visiting your account page and selecting the 'Orders' section, where the current status of your order will be displayed.</p>
    </div>

    <div class="faq-section">
        <h2>5. How long does delivery take?</h2>
        <p>Delivery times vary depending on your location and the chosen delivery option. Standard delivery usually takes 3-5 business days, while express delivery can take 1-2 business days.</p>
    </div>
</div>
</body>
</html>
