<?php
require_once 'dbconn.php';
session_start();

// Assume user is logged in and user_id is stored in session
$userId = $_SESSION['user_id'];

// Check if notification_id is passed
if (isset($_GET['notification_id'])) {
    $notificationId = intval($_GET['notification_id']);

    // Update the notification status to 'read'
    $stmt = $conn->prepare("UPDATE notifications SET status = 'read' WHERE notification_id = ? AND user_id = ?");
    $stmt->bind_param('ii', $notificationId, $userId);
    $stmt->execute();

    // Redirect back to the notifications page
    header("Location: UserNotifications.php");
    exit();
}
?>
