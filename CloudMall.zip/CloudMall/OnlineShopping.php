<?php
session_start();

// Check if the user is logged in
$isLoggedIn = isset($_SESSION["user_id"]);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cloud Mall</title>

    <!-- Stylesheets -->
    <style>
        /* General Styles */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4; /* Light background */
            color: #333; /* Dark text */
        }

        .container {
            width: 85%;
            margin: 0 auto;
        }

        h1, h2, h3, h4 {
            color: #000;
        }

        /* Header Styles */
        header {
            background-color: #000; /* Black background */
            color: #fff;
            padding: 10px 0;
        }

        .header-top {
            background-color: #333; /* Darker header top */
            padding: 5px 0;
            font-size: 0.9rem;
        }

        .header-top p {
            margin: 0;
            color: #fff; /* White text */
        }

        .header-links {
            list-style: none;
            display: flex;
            justify-content: flex-end;
            margin: 0;
            padding: 0;
        }

        .header-links li {
            margin-left: 15px;
        }

        .header-links a {
            color: #fff; /* White links */
            text-decoration: none;
            transition: color 0.3s;
        }

        .header-links a:hover {
            color: #FFD700; /* Yellow on hover */
        }

        .header-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
        }

        header h1 {
            color: #FFD700; /* Yellow title */
            font-size: 2.5rem; /* Increased size */
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        nav a {
            color: #FFD700; /* Yellow links */
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #fff; /* White on hover */
        }

        /* Hero Section */
        .hero {
            background-color: #FFD700; /* Yellow background */
            color: #000; /* Black text */
            padding: 50px 0;
            text-align: center;
        }

        .hero h2 {
            font-size: 2.5rem; /* Larger title */
            margin-bottom: 10px;
        }

        .hero p {
            font-size: 1.2rem; /* Slightly larger paragraph */
        }

        .hero .btn-primary {
            background-color: #000; /* Black button */
            color: #fff; /* White text */
            padding: 10px 20px;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .hero .btn-primary:hover {
            background-color: #333; /* Darker on hover */
        }

        /* Products Section */
        .products {
            padding: 50px 0;
            text-align: center;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .product-card {
            border: 1px solid #ddd;
            padding: 15px;
            background-color: #fff; /* White background */
            transition: transform 0.3s;
        }

        .product-card img {
            max-width: 100%;
            height: auto;
        }

        .product-card h3 {
            font-size: 1.2rem; /* Title size */
            margin: 10px 0;
            color: #000; /* Dark text */
        }

        .product-card p {
            font-size: 1rem;
            color: #FFD700; /* Yellow text */
        }

        .product-card button {
            background-color: #FFD700; /* Yellow button */
            color: #000; /* Black text */
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .product-card button:hover {
            background-color: #000; /* Black on hover */
            color: #fff; /* White text */
        }

        .product-card:hover {
            transform: translateY(-5px); /* Lift effect */
        }

        /* Benefits Section */
        .benefits {
            background-color: #000; /* Black background */
            color: #fff; /* White text */
            padding: 40px 0;
            display: flex;
            justify-content: space-between;
            text-align: center;
        }

        .benefit {
            width: 30%; /* Equal width for benefits */
        }

        .benefit i {
            font-size: 2.5rem; /* Icon size */
            margin-bottom: 10px;
            color: #FFD700; /* Yellow icons */
        }

        .benefit h3 {
            margin-bottom: 10px; /* Spacing */
        }

        .benefit p {
            font-size: 0.95rem; /* Paragraph size */
            line-height: 1.5;
        }

        /* Footer Styles */
        footer {
            background-color: #333; /* Dark background */
            color: #fff; /* White text */
            padding: 30px 0;
            text-align: center;
        }

        .footer-links {
            display: flex;
            justify-content: space-between;
            padding-bottom: 20px;
            border-bottom: 1px solid #444; /* Divider */
        }

        .footer-links div {
            flex: 1; /* Flexbox for equal spacing */
        }

        .footer-links h4 {
            font-size: 1.1rem; /* Header size */
            margin-bottom: 10px;
            color: #FFD700; /* Yellow text */
        }

        .footer-links ul {
            list-style: none;
            padding: 0;
        }

        .footer-links a {
            color: #fff; /* White links */
            text-decoration: none;
            font-size: 0.9rem; /* Link size */
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: #FFD700; /* Yellow on hover */
        }

        .social-media {
            display: flex;
            gap: 10px;
            justify-content: center; /* Center icons */
            margin-top: 10px;
        }

        .social-media a {
            color: #fff; /* White icons */
            font-size: 1.5rem; /* Icon size */
            transition: color 0.3s;
        }

        .social-media a:hover {
            color: #FFD700; /* Yellow on hover */
        }

        footer p {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #aaa;
        }

        /* Store Section */
        .stores-section {
            position: relative;
            padding: 50px 20px;
            color: #ffffff; 
            background-color: rgba(0, 0, 0, 0.6);
        }

        .stores-list {
            position: relative; 
            z-index: 1;
        }

        .stores-list h2 {
            color: #000;
            text-align: center;
            margin-bottom: 40px;
        }

        .store-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .store-card {
            text-align: center;
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            transition: transform 0.3s ease;
            display: flex;
            flex-direction: column; 
            justify-content: space-between;
            height: 80%;
            text-decoration: none;
        }

        .store-card:hover {
            transform: scale(1.05); /* Grow effect */
        }

        .store-logo {
            max-width: 150px; 
            height: auto; 
            margin-bottom: 10px;
        }

        .store-card h3 {
            color: #fbc02d;
            margin-top: 20px;
        }

        /* Slideshow Styles */
        .slideshow-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0; 
        }

        .slideshow-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0;
            position: absolute;
            top: 0;
            left: 0;
            transition: opacity 1s ease-in-out;
        }

        /* Show active slide */
        .slides.active .slideshow-img {
            opacity: 1;
        }
    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-top">
            <div class="container">
                <p>Free shipping on orders over R750!</p>
                <ul class="header-links">
                    <li><a href="Carts.php">Carts<i class="fas fa-shopping-cart"></i></a></li>
                    <li><a href="Orders.php">My Orders</a></li>
                    <?php if ($isLoggedIn): ?>
                        <!-- Show Logout and Dashboard when logged in -->
                        <li><a href="UserProfileUpdate.php" class="btn-primary">Profile</a></li>
                        <li><a href="UserNotifications.php" class="btn-primary">Notifications</a></li>
                        <li><a href="Logout.php" class="btn-primary">Logout</a></li>
                    <?php else: ?>
                        <!-- Show Login and Sign Up when not logged in -->
                        <li><a href="Login.php">Login</a></li>
                        <li><a href="SignUp.php">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <div class="header-main">
            <div class="container">
                <h1>Cloud Mall</h1>
                <nav>
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li><a href="Shops.php">Shop</a></li>
                        <li><a href="AboutUs.php">About Us</a></li>
                        <li><a href="Contact.php">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h2>Find the Best Products Here</h2>
            <p><i>Find Every Product You Need Here.<br>All-In-One Stop.<br>Your Online Shopping Mall... </i></p>
            <a href="Shops.php" class="btn-primary">Shop Now</a>
        </div>
    </section>

    <!-- Stores Section -->
    <section class="stores-section">
        <div class="slideshow-container">
            <!-- Slideshow Images -->
            <div class="slides fade">
                <img src="https://cdn.apartmenttherapy.info/image/upload/f_auto,q_auto:eco,w_730/k%2FPhoto%2FSeries%2F2019-10--power-hour-instant-pot%2FPower-Hour-Instant-Pot_001-rotated" alt="Food" class="slideshow-img">
            </div>
            <div class="slides fade">
                <img src="https://static.vecteezy.com/system/resources/thumbnails/029/305/833/small_2x/clothing-shop-s-hangers-exhibit-modern-fashion-highlighting-the-boutique-s-stylish-ambiance-ai-generated-photo.jpg" alt="Clothing" class="slideshow-img">
            </div>
            <div class="slides fade">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgfPu0V5-5sve1p_5tkDjU8prMTe8onCzG-Q&s" alt="Accessories" class="slideshow-img">
            </div>
        </div>

        <div class="container stores-list">
            <h2>Featured Stores</h2>
            <div class="store-grid">
                <!-- Store Items -->
                <a href="#" class="store-card">
                    <div class="store-card">
                        <img src="https://companieslogo.com/img/orig/SHP.JO-f9b5c24d.png?t=1720244493" alt="Shoprite Logo" class="shop-logo">
                        <h3>Shoprite</h3>
                    </div>
                </a>
                <a href="#" class="store-card">
                    <div class="store-card">
                        <img src="https://boardwalkinkwazi.co.za/media/com_jbusinessdirectory/pictures/companies/204/checkers-1515755483.jpg" alt="Checkers Logo" class="shop-logo">
                        <h3>Checkers</h3>
                    </div>
                </a>
                <a href="#" class="store-card">
                    <div class="store-card">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSajaDKOakr5k1QOn2rqFOyxATXuD5UMXQ5VA&s" alt="Spar Logo" class="shop-logo">
                        <h3>Spar</h3>
                    </div>
                </a>
                <a href="#" class="store-card">
                    <div class="store-card">
                        <img src="https://pbs.twimg.com/profile_images/1722162942349619201/DLn1jcst_400x400.jpg" alt="Boxer Logo" class="shop-logo">
                        <h3>Boxer</h3>
                    </div>
                </a>
                
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <div class="container">
            <div class="footer-links">
                <div>
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li><a href="Shops.php">Shop</a></li>
                        <li><a href="AboutUs.php">About Us</a></li>
                        <li><a href="Contact.php">Contact</a></li>
                    </ul>
                </div>
                <div>
                    <h4>Customer Service</h4>
                    <ul>
                        <li><a href= "FAQ.php">FAQ</a></li>
                        <li><a href="UserReturnRequest.php">Returns</a></li>
                        <li><a href="PrivacyPolicy.php">Privacy Policy</a></li>
                    </ul>
                </div>
                <<div>
                    <h4>Connect With Us</h4>
                    <p>Follow us on social media:</p>
                    <ul class="social-media">
                        <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                        <li><a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
    </footer>

    <!-- JavaScript for Slideshow -->
    <script>
        let slideIndex = 0;
        showSlides();

        function showSlides() {
            const slides = document.getElementsByClassName("slides");
            for (let i = 0; i < slides.length; i++) {
                slides[i].classList.remove("active");
            }
            slideIndex++;
            if (slideIndex > slides.length) {slideIndex = 1}
            slides[slideIndex - 1].classList.add("active");
            setTimeout(showSlides, 5000); // Change image every 5 seconds
        }
    </script>

</body>
</html>
