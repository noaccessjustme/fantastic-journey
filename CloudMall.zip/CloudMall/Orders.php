<?php
session_start();

// require_once 'session.php'; // Include session management
require_once 'dbconn.php'; // Include database connection

// Check if the user ID exists in the session
if (!isset($_SESSION['user_id'])) {
    echo "No user found.";
    exit;
}

// Get the user ID from the session
$isLoggedIn = $_SESSION["user_id"];
// $isLoggedIn =8;


// Fetch orders for the user from the database
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ?");
$stmt->bind_param("i",$isLoggedIn);
$stmt->execute();
$orderResult = $stmt->get_result();

if ($orderResult->num_rows === 0) {
    echo "No orders found for this user.";
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .order-summary {
            margin-bottom: 20px;
        }
        .order-summary h2 {
            margin-bottom: 10px;
            color: #FFD700;
        }
        .order-item {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .total {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 10px;
        }
        footer {
            text-align: center;
            margin-top: 20px;
            color: #333;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }
        .home-button {
            position: absolute;
            top: 20px; /* Distance from the top */
            right: 20px; /* Distance from the right */
            background-color: #333;
            color: #fff;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .home-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .home-button:hover {
            background-color: #555;
        }
    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">    
</head>
<body>

<button class="back-button" onclick="window.history.back();">Back</button> <!-- Back button -->
<a href="OnlineShopping.php"><button class="home-button">Back to Home</button></a>

<div class="container">
    <h1>Order Confirmation</h1>

    <?php while ($order = $orderResult->fetch_assoc()): ?>
        <div class="order-summary">
            <h2>Order ID: <?= htmlspecialchars($order['order_id']) ?></h2>
            <p><strong>User ID:</strong> <?= htmlspecialchars($order['user_id']) ?></p>
            <p><strong>Total Amount:</strong> R<?= number_format($order['total_amount'], 2) ?></p>
            <p><strong>Payment Method:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
            <p><strong>Order Status:</strong> <?= htmlspecialchars($order['order_status']) ?></p>
            <p><strong>Order Created At:</strong> <?= htmlspecialchars($order['created_at']) ?></p>

            <?php

            // Fetch order items for each order
            $itemStmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
            $itemStmt->bind_param("i", $order['order_id']);
            $itemStmt->execute();
            $orderItemsResult = $itemStmt->get_result();
            ?>

            <h2>Order Items</h2>
            <?php while ($item = $orderItemsResult->fetch_assoc()): ?>
                <div class="order-item">
                    <p><strong>Product ID:</strong> <?= htmlspecialchars($item['product_id']) ?></p>
                    <p><strong>Quantity:</strong> <?= htmlspecialchars($item['quantity']) ?></p>
                    <p><strong>Price:</strong> R<?= number_format($item['price'], 2) ?></p>
                </div>
            <?php endwhile; ?>

            <div class="total">
                Total: R<?= number_format($order['total_amount'], 2) ?>
            </div>
        </div>
    <?php endwhile; ?>
    
</div>

<footer>
    <p>&copy; 2024 Cloud Mall. Thank you for your purchase!</p>
</footer>
</body>
</html>
