<?php 
require_once 'session.php';
require_once 'dbconn.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure the user is logged in and the user_id is set in the session
if (!isset($_SESSION['user_id'])) {
    echo "You must be logged in to proceed with payment.";
    header("Location: Login.php"); // Redirect to login page if not logged in
    exit();
}

// Get the logged-in user ID from the session
$isLoggedin = $_SESSION['user_id'];

// Fetch all shops from the database
$shopQuery = "SELECT shop_id, shop_name FROM shops";
$shopStmt = $conn->prepare($shopQuery);
$shopStmt->execute();
$shops = $shopStmt->get_result();

// Check if the shop_id is provided in the URL
if (!isset($_GET['shop_id'])) {
    echo "Shop not found! Please select a shop.";
    exit();
}

// Get the shop_id from the URL
$shop_id = intval($_GET['shop_id']);

// Fetch total amount from the carts table for the specific shop
$query = "SELECT SUM(total) as total_amount FROM carts WHERE user_id = ? AND shop_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $isLoggedin, $shop_id);
$stmt->execute();
$result = $stmt->get_result();
$total_data = $result->fetch_assoc();
$totalAmount = isset($total_data['total_amount']) ? $total_data['total_amount'] : 0;

// Fetch user email from the database
$email_query = "SELECT email FROM users WHERE user_id = ?";
$email_stmt = $conn->prepare($email_query);
$email_stmt->bind_param("i", $isLoggedin);
$email_stmt->execute();
$email_result = $email_stmt->get_result();
$user_email = $email_result->fetch_assoc()['email'];

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $delivery_option = $_POST['delivery_option'];
    $address = $delivery_option === 'delivery' ? $_POST['residence_address'] : null;
    $contact = $delivery_option === 'delivery' ? $_POST['contact'] : null;
    $payment_method = $_POST['payment_method'];
    $total_amount = $_POST['total_amount'];

    // Insert order details into the database, including delivery and contact information
    $order_stmt = $conn->prepare("
        INSERT INTO orders (user_id, total_amount, payment_method, delivery_option, residence_address, contact, order_status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW())
    ");
    $order_stmt->bind_param("idssss", $isLoggedin, $total_amount, $payment_method, $delivery_option, $address, $contact);

    $order_stmt->execute();

    // Redirect to Orders page after successful submission
    header("Location: Orders.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Shop and Payment</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            color: #333;
            padding: 20px;
        }

        .shop-container, .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        /* Grid layout for shop selection */
        .shop-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .shop-link {
            background-color: #fbc02d;
            color: #333;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .shop-link:hover {
            background-color: #f57c00;
            color: #fff;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
        }

        .input-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .hidden {
            display: none;
        }

        .button {
            padding: 10px 20px;
            background-color: #333;
            color: #fbc02d;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 10px;
            display: inline-block;
        }

        .button:hover {
            background-color: #555;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }
    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
</head>

<body>

<button class="back-button" onclick="window.history.back();">Back</button> <!-- Back button -->

<div class="shop-container">
    <h1>Select a Shop</h1>
    <div class="shop-grid">
    <?php
    while ($shop = $shops->fetch_assoc()) {
        echo '<a class="shop-link" href="Payment.php?shop_id=' . $shop['shop_id'] . '">' . htmlspecialchars($shop['shop_name']) . '</a>';
    }
    ?>
    </div>
</div>

<div class="container">
    <h1>Payment</h1>

    <p>Total Amount: R<?= number_format($totalAmount, 2); ?></p>

    <form action="Payment.php?shop_id=<?= $shop_id; ?>" method="POST">
        <div class="payment-option">
            <label for="collection-option">
                <input type="radio" name="delivery_option" id="collection-option" value="self" checked>
                Self Collection
            </label>
            <label for="delivery-option">
                <input type="radio" name="delivery_option" id="delivery-option" value="delivery">
                Delivery
            </label>
        </div>

        <div id="delivery-details" class="hidden">
            <h3>Delivery Details</h3>
            <div class="input-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" placeholder="Enter your delivery address">
            </div>
            <div class="input-group">
                <label for="contact">Contact Number:</label>
                <input type="text" id="contact" name="contact" placeholder="Enter your contact number">
            </div>
        </div>

        <div class="payment-option">
            <h3>Select Payment Method:</h3>
            <label for="paypal-option">
                <input type="radio" name="payment_method" id="paypal-option" value="paypal" checked>
                PayPal
            </label>
            <label for="credit-card-option">
                <input type="radio" name="payment_method" id="credit-card-option" value="credit_card">
                Credit Card
            </label>
        </div>

        <div id="payment-details">
            <div id="paypal-details" class="payment-inputs">
                <h3>PayPal Payment Details</h3>
                <div class="input-group">
                    <label for="paypal-email">PayPal Email:</label>
                    <input type="email" id="paypal-email" name="paypal_email" placeholder="Enter your PayPal email">
                </div>
            </div>

            <div id="credit-card-details" class="payment-inputs hidden">
                <h3>Credit Card Payment Details</h3>
                <div class="input-group">
                    <label for="card-number">Card Number:</label>
                    <input type="text" id="card-number" name="card_number" placeholder="Enter your card number">
                </div>
                <div class="input-group">
                    <label for="expiry-date">Expiry Date (MM/YY):</label>
                    <input type="text" id="expiry-date" name="expiry_date" placeholder="MM/YY">
                </div>
                <div class="input-group">
                    <label for="cvv">CVV:</label>
                    <input type="text" id="cvv" name="cvv" placeholder="CVV">
                </div>
            </div>
        </div>

        <input type="hidden" name="total_amount" value="<?= number_format($totalAmount, 2); ?>">
        <button class="button" type="submit">Pay Now</button>
    </form>
</div>

<script>
    // Handle delivery option toggle
    document.querySelectorAll('input[name="delivery_option"]').forEach(function (elem) {
        elem.addEventListener('change', function () {
            const deliveryDetails = document.getElementById('delivery-details');
            if (this.value === 'delivery') {
                deliveryDetails.classList.remove('hidden');
            } else {
                deliveryDetails.classList.add('hidden');
            }
        });
    });

    // Handle payment method toggle
    document.querySelectorAll('input[name="payment_method"]').forEach(function (elem) {
        elem.addEventListener('change', function () {
            const paypalDetails = document.getElementById('paypal-details');
            const creditCardDetails = document.getElementById('credit-card-details');
            if (this.value === 'paypal') {
                paypalDetails.classList.remove('hidden');
                creditCardDetails.classList.add('hidden');
            } else {
                paypalDetails.classList.add('hidden');
                creditCardDetails.classList.remove('hidden');
            }
        });
    });
</script>

</body>
</html>
