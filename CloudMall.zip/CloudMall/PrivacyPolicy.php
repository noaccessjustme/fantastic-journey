<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            color: #333;
        }
        p {
            line-height: 1.6;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Privacy Policy</h1>
    <p>This Privacy Policy outlines how we handle your personal information when you use our services.</p>

    <h2>1. Information Collection</h2>
    <p>We collect personal information such as your name, email address, contact details, and payment information when you place an order or create an account on our platform.</p>

    <h2>2. Use of Information</h2>
    <p>Your personal information is used to process your orders, manage your account, and improve our services. We may also send you promotional materials based on your preferences.</p>

    <h2>3. Information Sharing</h2>
    <p>We do not share your personal information with third parties, except for those necessary to fulfill your orders (such as delivery partners and payment processors).</p>

    <h2>4. Security</h2>
    <p>We are committed to ensuring the security of your personal information. We use industry-standard security measures to protect your data.</p>

    <h2>5. Your Rights</h2>
    <p>You have the right to access, update, or delete your personal information at any time. Please contact us if you wish to exercise these rights.</p>

    <h2>6. Changes to the Privacy Policy</h2>
    <p>We may update this Privacy Policy from time to time. You will be notified of any significant changes via email or a notice on our website.</p>

    <h2>7. Contact Us</h2>
    <p>If you have any questions or concerns regarding this Privacy Policy, please contact us at privacy@yourshop.com.</p>
</div>
</body>
</html>
