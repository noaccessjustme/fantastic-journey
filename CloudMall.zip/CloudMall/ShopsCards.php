<?php
require_once 'dbconn.php'; // Include database connection
require_once 'session.php'; // Include session management

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Fetch available stores from the database
$stmt = $conn->prepare("SELECT shop_id, shop_name, shop_logo FROM shops");
$stmt->execute();
$result = $stmt->get_result();
$stores = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Selection</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}
.store-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 30px;
}
.store-card {
    border: 1px solid #ddd;
    padding: 20px;
    text-align: center;
    background-color: #fff;
    transition: transform 0.3s ease-in-out;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    min-height: 250px; /* Ensure all cards have the same height */
}
.store-card img {
    max-width: 100%;
    height: 150px; /* Set fixed height */
    width: auto;
    object-fit: contain; /* Ensure images scale properly */
}
.store-card h3 {
    margin: 10px 0;
    flex-grow: 1; /* Pushes the content down evenly */
}
.store-card:hover {
    transform: scale(1.05);
}
.store-card a {
    text-decoration: none;
    color: #333;
    background-color: yellow;
    padding: 10px 20px;
    border-radius: 5px;
    display: inline-block;
    margin-top: 10px;
    margin-bottom: 0;
    align-self: center;
}
.store-card a:hover {
    background-color: #d4c000;
}

    </style>
</head>
<body>

<h1 style="text-align:center;color:#333;">Select a Store</h1>

<div class="store-cards">
    <?php foreach ($stores as $store): ?>
        <div class="store-card">
            <img src="<?php echo $store['shop_logo']; ?>" alt="<?php echo $store['shop_name']; ?> Logo">
            <h3><?php echo $store['shop_name']; ?></h3>
            <a href="Carts.php?shop_id=<?php echo $store['shop_id']; ?>">Go to Cart</a>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>
