<?php
require_once 'session.php';
require_once 'dbconn.php';

// Initialize error variables
$firstnameErr = $lastnameErr = $emailErr = $passwordErr = $confirmPasswordErr = "";
$firstname = $lastname = $email = $password = $confirmPassword = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate first name
    if (empty($_POST["firstname"])) {
        $firstnameErr = "First name is required";
    } else {
        $firstname = htmlspecialchars($_POST["firstname"]);
    }

    // Validate last name
    if (empty($_POST["lastname"])) {
        $lastnameErr = "Last name is required";
    } else {
        $lastname = htmlspecialchars($_POST["lastname"]);
    }

    // Validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = htmlspecialchars($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        } else {
            // Check if email already exists in the database
            $emailCheckQuery = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
            $emailCheckQuery->bind_param("s", $email);
            $emailCheckQuery->execute();
            $emailCheckQuery->store_result();
            if ($emailCheckQuery->num_rows > 0) {
                $emailErr = "Email already exists!";
            }
            $emailCheckQuery->close();
        }
    }

    // Validate password
    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } elseif (strlen($_POST["password"]) < 6) {
        $passwordErr = "Password must be at least 6 characters long";
    } else {
        $password = $_POST["password"];
    }

    // Confirm password
    if (empty($_POST["confirm-password"])) {
        $confirmPasswordErr = "Please confirm your password";
    } elseif ($_POST["confirm-password"] !== $password) {
        $confirmPasswordErr = "Passwords do not match";
    }

    // If no errors, insert data into the database
    if (empty($firstnameErr) && empty($lastnameErr) && empty($emailErr) && empty($passwordErr) && empty($confirmPasswordErr)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Set user role to customer by default
        $role = 'customer'; 

        $insertQuery = $conn->prepare("INSERT INTO users (firstname, lastname, email, hash_password, user_role, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $insertQuery->bind_param("sssss", $firstname, $lastname, $email, $hashedPassword, $role);

        if ($insertQuery->execute()) {
            header("Location: Login.php");
        } else {
            echo "Error: " . $insertQuery->error;
        }

        $insertQuery->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #fff; /* White background */
        }

        /* Form Styles */
        #signup-form {
            background-color: #000; /* Black background for the form */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 300px;
        }

        #signup-form input, #signup-form select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
        }

        /* Input Fields */
        #signup-form input[type="email"],
        #signup-form input[type="password"] {
            background-color: #fff; /* White input fields */
            color: #000; /* Black text */
        }

        /* Placeholder Styling */
        #signup-form input::placeholder {
            color: #333; /* Darker placeholder text */
        }

        /* Button Styles */
        #signup-form button {
            background-color: #FFD700; /* Yellow background for the button */
            color: #000; /* Black text */
            padding: 10px;
            width: 100%;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        #signup-form button:hover {
            background-color: #FFC107; /* Slightly darker yellow on hover */
        }

        /* Error Messages */
        .error {
            color: red;
            font-size: 12px;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    
<button class="back-button" onclick="window.history.back();">Back</button> <!-- Back button -->

    <form id="signup-form" action="SignUp.php" method="post">
        <input type="text" name="firstname" placeholder="First name" value="<?php echo htmlspecialchars($firstname); ?>" required>
        <span class="error"><?php echo $firstnameErr; ?></span>

        <input type="text" name="lastname" placeholder="Last name" value="<?php echo htmlspecialchars($lastname); ?>" required>
        <span class="error"><?php echo $lastnameErr; ?></span>

        <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($email); ?>" required>
        <span class="error"><?php echo $emailErr; ?></span>

        <input type="password" name="password" placeholder="Password" required>
        <span class="error"><?php echo $passwordErr; ?></span>

        <input type="password" name="confirm-password" placeholder="Confirm Password" required>
        <span class="error"><?php echo $confirmPasswordErr; ?></span>

        <!-- Removed role selection for security -->
        <input type="hidden" name="role" value="customer"> <!-- Set role to customer directly -->

        <button type="submit">Sign Up</button>
    </form>
</body>
</html>
