<?php
require_once 'dbconn.php';
session_start();

// Assume user is logged in and user_id is stored in session
$userId = $_SESSION['user_id'];

// Fetch unread notifications for the user
$stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? AND status = 'unread'");
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result();
$unreadNotifications = $result->num_rows; // Get the number of unread notifications

// Fetch all notifications for the user
$stmtAll = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
$stmtAll->bind_param('i', $userId);
$stmtAll->execute();
$allNotifications = $stmtAll->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Notifications</title>
    <style>
        .notification-icon {
            position: relative;
            display: inline-block;
        }
        .notification-icon .badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: red;
            color: white;
            padding: 5px 10px;
            border-radius: 50%;
        }
        .notification {
            background-color: #f4f4f4;
            margin: 10px 0;
            padding: 15px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .notification.read {
            background-color: #ddd;
        }
    </style>
</head>
<body>
    <h1>Your Notifications</h1>

    <div class="notification-icon">
        <a href="UserNotifications.php">
            <i class="fas fa-bell"></i> <!-- Notification bell icon -->
            <?php if ($unreadNotifications > 0): ?>
                <span class="badge"><?php echo $unreadNotifications; ?></span> <!-- Unread notification count -->
            <?php endif; ?>
        </a>
    </div>

    <div>
        <?php while ($notification = $allNotifications->fetch_assoc()): ?>
            <div class="notification <?php echo ($notification['status'] == 'read') ? 'read' : ''; ?>">
                <p><?php echo $notification['message']; ?></p>
                <small><?php echo date('F j, Y, g:i a', strtotime($notification['created_at'])); ?></small>
                <?php if ($notification['status'] == 'unread'): ?>
                    <a href="MarkAsRead.php?notification_id=<?php echo $notification['notification_id']; ?>">Mark as Read</a>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
