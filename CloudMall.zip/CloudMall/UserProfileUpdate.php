<?php
require_once 'session.php'; // Include session management
require_once 'dbconn.php'; // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php"); // Redirect to login if not logged in
    exit();
}

// Get the logged-in user's ID from the session
$userID = $_SESSION['user_id'];

// Fetch user details from the database
$stmt = $conn->prepare("SELECT firstname, lastname, email FROM users WHERE user_id = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$userResult = $stmt->get_result();
$user = $userResult->fetch_assoc();

// Handle form submission to update user details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['firstname'];
    $contact = $_POST['lastname'];
    $email = $_POST['email'];
    
    

    // Update user details in the database
    $stmt = $conn->prepare("UPDATE users SET firstname = ?, lastname = ?, email = ? WHERE user_id = ?");
    $stmt->bind_param("sssi", $firstname, $lastname, $email, $userID);
    
    if ($stmt->execute()) {
        $successMessage = "Profile updated successfully!";
        header("Location: UserProfileUpdate.php"); // Refresh the page after updating
        exit();
    } else {
        $errorMessage = "Failed to update profile!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <style>
        .profile-container {
            margin: 20px auto;
            padding: 20px;
            max-width: 600px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            color: #333;
            font-size: 2rem;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>

<div class="profile-container">
    <h2>My Profile</h2>

    <?php if (isset($successMessage)) : ?>
        <p class="message"><?= $successMessage; ?></p>
    <?php elseif (isset($errorMessage)) : ?>
        <p class="error"><?= $errorMessage; ?></p>
    <?php endif; ?>

    <form action="" method="POST">
        <div class="form-group">
            <label for="firstname">First Name</label>
            <input type="text" name="firstname" id="firstname" value="<?= htmlspecialchars($user['firstname']); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="<?= htmlspecialchars($user['email']); ?>" required>
        </div>
        <div class="form-group">
            <label for="lastname">First Name</label>
            <input type="text" name="lastname" id="lastname" value="<?= htmlspecialchars($user['lastname']); ?>" required>
        </div>

        <button type="submit">Update Profile</button>
    </form>

    <a href="OnlineShopping.php">Back to Home</a>
</div>

</body>
</html>
