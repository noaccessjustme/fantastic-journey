<?php
require_once 'session.php'; // Include session management
require_once 'dbconn.php';  // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id']; // Get logged-in user's ID

// Handle return request submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_id = $_POST['order_id'];
    $product_name = $_POST['product_name'];
    $reason = $_POST['reason'];

    // Get the product_id based on the product_name input (assuming product names are unique)
    $stmt = $conn->prepare("SELECT product_id FROM products WHERE product_name = ?");
    $stmt->bind_param("s", $product_name);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
        $product_id = $product['product_id'];

        // Insert the return request into the returns table
        $stmt = $conn->prepare("INSERT INTO returns (order_id, user_id, product_id, reason) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiis", $order_id, $user_id, $product_id, $reason);
        if ($stmt->execute()) {
            echo "Return request submitted successfully! You will receive a notification once it's processed.";
        } else {
            echo "Failed to submit return request.";
        }
    } else {
        echo "Invalid product name. Please check the product name and try again.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Product Return</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label, input, textarea {
            margin-bottom: 10px;
        }
        input, textarea {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px;
            background-color: #fbc02d;
            color: #333;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Request Product Return</h2>

    <form method="POST" action="">
        <label for="order_id">Order Number</label>
        <input type="number" name="order_id" id="order_id" placeholder="Enter your order number" required>

        <label for="product_name">Product Name</label>
        <input type="text" name="product_name" id="product_name" placeholder="Enter the product name" required>

        <label for="reason">Reason for Return</label>
        <textarea name="reason" id="reason" rows="4" placeholder="Explain the reason for return" required></textarea>

        <button type="submit">Submit Return Request</button>
    </form>
</div>

</body>
</html>
