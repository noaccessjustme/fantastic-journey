<?php
/*/ admin_header.php

// Include session start and database connection
require_once 'session.php';
require_once 'dbconn.php';

// Check if the user is an admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    // If not an admin, redirect to login or error page
    header('Location: Login.php');
    exit();
}
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        /* admin_styles.css */

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4; /* Neutral background for content clarity */
            color: #333; /* Text color */
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #2b2b2b; /* Primary color, if dark */
            padding: 20px 0;
        }

        .admin-nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .admin-nav li {
            margin: 0 15px;
        }

        .admin-nav a {
            text-decoration: none;
            color: #fff; /* White text for contrast on dark background */
            padding: 10px 20px;
            background-color: #4CAF50; /* Primary action color */
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .admin-nav a:hover {
            background-color: #45a049; /* Slightly lighter green for hover */
        }
        .admin-container {
            margin: 20px auto;
            padding: 20px;
            max-width: 1200px;
            background-color: #fff; /* Light background for readability */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Soft shadow to lift the container */
            border-radius: 10px;
        }

        h1, h2, h3 {
            color: #333; /* Darker text for headings */
        }

        p, label {
            color: #666; /* Slightly lighter text for body content */
        }

        button {
            background-color: #4CAF50; /* Primary button color */
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049; /* Lighter hover effect */
        }


    </style>
</head>
<body>

<!-- Admin Navigation Menu -->
<header>
    <nav class="admin-nav">
    <button class="btn" onclick="window.history.back();">Back</button> <!-- Back button -->
        <ul>
            <li><a href="AdminDashboard.php">Dashboard</a></li>
            <li><a href="AdminProductManager.php">Products</a></li>
            <li><a href="AdminOrderManager.php">Orders</a></li>
            <li><a href="AdminUserManager.php">Users</a></li>
            <li><a href="AdminShopManager.php">Shops</a></li>
            <li><a href="AdminCheck&ReplyReports.php">Reports</a></li>
            <li><a href="AdminReturnsReplies.php">Returns</a></li>
            <li><a href="AdmincreateNotification.php">Notifications</a></li>
            <li><a href="Logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="admin-container">
    <!-- The admin container div will hold the page-specific content -->
