<?php
// Database connection
$servername = "localhost";
$username = "root";
$password_db = "";
$dbname = "cloud_mall";

// Create a new connection
$conn = new mysqli($servername, $username, $password_db, $dbname);

// Check if connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
